// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#include "JSONLiveLinkSource.h"
#include "Logging/LogMacros.h"          // For logging macros
#include "Dom/JsonObject.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

#include "ILiveLinkClient.h"
#include "LiveLinkTypes.h"
#include "Roles/LiveLinkAnimationRole.h"
#include "Roles/LiveLinkAnimationTypes.h"

#include "Async/Async.h"
#include "Common/UdpSocketBuilder.h"
#include "HAL/RunnableThread.h"
#include "Sockets.h"
#include "SocketSubsystem.h"

#include "Roles/LiveLinkCameraTypes.h"
#include "Roles/LiveLinkCameraRole.h"
#include "Roles/LiveLinkLightRole.h"
#include "Roles/LiveLinkLightTypes.h"
#include "Roles/LiveLinkTransformRole.h"
#include "Roles/LiveLinkTransformTypes.h"

// Enable logging step 2
DEFINE_LOG_CATEGORY(ModuleLog)

#define LOCTEXT_NAMESPACE "JSONLiveLinkSource"

#define RECV_BUFFER_SIZE 1024 * 1024

FJSONLiveLinkSource::FJSONLiveLinkSource(FIPv4Endpoint InEndpoint)
	: Socket(nullptr)
	, Stopping(false)
	, Thread(nullptr)
	, WaitTime(FTimespan::FromMilliseconds(100))
{
	// Defaults
	DeviceEndpoint = InEndpoint;

	SourceStatus = LOCTEXT("SourceStatus_DeviceNotFound", "Device Not Found");
	SourceType = LOCTEXT("JSONLiveLinkSourceType", "JSON LiveLink");
	SourceMachineName = LOCTEXT("JSONLiveLinkSourceMachineName", "localhost");

	UE_LOG(ModuleLog, Warning, TEXT("Setup socket"));
	// Setup socket
	if (DeviceEndpoint.Address.IsMulticastAddress())
	{
		Socket = FUdpSocketBuilder(TEXT("JSONSOCKET"))
			.AsNonBlocking()
			.AsReusable()
			.BoundToPort(DeviceEndpoint.Port)
			.WithReceiveBufferSize(RECV_BUFFER_SIZE)
			.BoundToAddress(FIPv4Address::Any)
			.JoinedToGroup(DeviceEndpoint.Address)
			.WithMulticastLoopback()
			.WithMulticastTtl(2);
	}
	else
	{
		Socket = FUdpSocketBuilder(TEXT("JSONSOCKET"))
			.AsNonBlocking()
			.AsReusable()
			.BoundToAddress(DeviceEndpoint.Address)
			.BoundToPort(DeviceEndpoint.Port)
			.WithReceiveBufferSize(RECV_BUFFER_SIZE);
	}

	RecvBuffer.SetNumUninitialized(RECV_BUFFER_SIZE);

	if ((Socket != nullptr) && (Socket->GetSocketType() == SOCKTYPE_Datagram))
	{
		SocketSubsystem = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
		Start();
		SourceStatus = LOCTEXT("SourceStatus_Receiving", "Receiving");
	}
}

FJSONLiveLinkSource::~FJSONLiveLinkSource()
{
	Stop();
	if (Thread != nullptr)
	{
		Thread->WaitForCompletion();
		delete Thread;
		Thread = nullptr;
	}
	if (Socket != nullptr)
	{
		Socket->Close();
		ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(Socket);
	}
}

void FJSONLiveLinkSource::ReceiveClient(ILiveLinkClient* InClient, FGuid InSourceGuid)
{
	Client = InClient;
	SourceGuid = InSourceGuid;
}

bool FJSONLiveLinkSource::IsSourceStillValid() const
{
	// Source is valid if we have a valid thread and socket
	bool bIsSourceValid = !Stopping && Thread != nullptr && Socket != nullptr;
	return bIsSourceValid;
}

bool FJSONLiveLinkSource::RequestSourceShutdown()
{
	Stop();
	Client = nullptr; // Clear the client pointer so that asynchronous tasks immediately return.
	return true;
}

// FRunnable interface

void FJSONLiveLinkSource::Start()
{
	ThreadName = "JSON UDP Receiver ";
	ThreadName.AppendInt(FAsyncThreadIndex::GetNext());
	Thread = FRunnableThread::Create(this, *ThreadName, 128 * 1024, TPri_AboveNormal, FPlatformAffinity::GetPoolThreadMask());
}

void FJSONLiveLinkSource::Stop()
{
	Stopping = true;
}

uint32 FJSONLiveLinkSource::Run()
{
	TSharedRef<FInternetAddr> Sender = SocketSubsystem->CreateInternetAddr();

	while (!Stopping)
	{
		if (Socket->Wait(ESocketWaitConditions::WaitForRead, WaitTime))
		{
			uint32 Size;

			while (Socket->HasPendingData(Size))
			{
				int32 Read = 0;

				if (Socket->RecvFrom(RecvBuffer.GetData(), RecvBuffer.Num(), Read, *Sender))
				{
					if (Read > 0)
					{
						// If stopping, skip scheduling async tasks.
						if (Stopping)
						{
							continue;
						}

						TSharedPtr<TArray<uint8>, ESPMode::ThreadSafe> ReceivedData = MakeShareable(new TArray<uint8>());
						ReceivedData->SetNumUninitialized(Read);
						memcpy(ReceivedData->GetData(), RecvBuffer.GetData(), Read);

						// Check again if stopping before calling AsShared().
						if (Stopping)
						{
							continue;
						}

						// Capture a weak pointer using a unique name to avoid naming conflicts.
						TWeakPtr<FJSONLiveLinkSource> LocalWeakThis = AsShared();
						AsyncTask(ENamedThreads::GameThread, [LocalWeakThis, ReceivedData]()
							{
								if (TSharedPtr<FJSONLiveLinkSource> Pinned = LocalWeakThis.Pin())
								{
									Pinned->HandleReceivedData(ReceivedData);
								}
							});
					}
				}
			}
		}
	}
	return 0;
}

void FJSONLiveLinkSource::HandleReceivedData(TSharedPtr<TArray<uint8>, ESPMode::ThreadSafe> ReceivedData)
{
	// If we're shutting down or the client is no longer valid, do nothing.
	if (Stopping || Client == nullptr)
	{
		return;
	}

	// Process JSON data.
	FString JsonString;
	JsonString.Empty(ReceivedData->Num());
	for (uint8& Byte : *ReceivedData.Get())
	{
		JsonString += TCHAR(Byte);
	}

	// Type values from the JSON.
	FString validtypes = FString("CharacterSubject CharacterAnimation CameraSubject CameraAnimation LightSubject LightAnimation TransformSubject TransformAnimation");

	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonString);
	if (FJsonSerializer::Deserialize(Reader, JsonObject))
	{
		for (TPair<FString, TSharedPtr<FJsonValue>>& JsonField : JsonObject->Values)
		{
			FName SubjectName(*JsonField.Key);
			const TArray<TSharedPtr<FJsonValue>>& BoneArray = JsonField.Value->AsArray();

			// Type of JSON data found in the first value of the BoneArray.
			const TSharedPtr<FJsonValue>& MyType = BoneArray[0];
			const TSharedPtr<FJsonObject> MyTypeObject = MyType->AsObject();

			FString MyTypeName;
			if (MyTypeObject->TryGetStringField(TEXT("Type"), MyTypeName))
			{
				if (!validtypes.Contains(MyTypeName))
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid type: %s"), *FString(MyTypeName));
					return;
				}
			}
			else
			{
				UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid json 'Type' value not found"));
				return;
			}

			bool bCreateSubject = !EncounteredSubjects.Contains(SubjectName);

			// Camera Subject
			if (bCreateSubject && MyTypeName == "CameraSubject")
			{
				UE_LOG(ModuleLog, Warning, TEXT("HandleReceivedData - CameraSubject"));
				FLiveLinkStaticDataStruct StaticDataStruct = FLiveLinkStaticDataStruct(FLiveLinkCameraStaticData::StaticStruct());
				FLiveLinkCameraStaticData& CameraData = *StaticDataStruct.Cast<FLiveLinkCameraStaticData>();

				const TSharedPtr<FJsonValue>& Cam = BoneArray[1];
				const TSharedPtr<FJsonObject> CamObject = Cam->AsObject();

				bool FieldOfView, AspectRatio, FocalLength, ProjectionMode;
				if (CamObject->TryGetBoolField(TEXT("FieldOfView"), FieldOfView))
				{
					CameraData.bIsFieldOfViewSupported = FieldOfView;
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid data, FieldOfView value not found."));
					CameraData.bIsFieldOfViewSupported = false;
				}

				if (CamObject->TryGetBoolField(TEXT("AspectRatio"), AspectRatio))
				{
					CameraData.bIsAspectRatioSupported = AspectRatio;
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid data, AspectRatio value not found."));
					CameraData.bIsAspectRatioSupported = false;
				}

				if (CamObject->TryGetBoolField(TEXT("FocalLength"), FocalLength))
				{
					CameraData.bIsFocalLengthSupported = FocalLength;
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid data, FocalLength value not found."));
					CameraData.bIsFocalLengthSupported = false;
				}

				if (CamObject->TryGetBoolField(TEXT("ProjectionMode"), ProjectionMode))
				{
					CameraData.bIsProjectionModeSupported = ProjectionMode;
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid data, ProjectionMode value not found."));
					CameraData.bIsProjectionModeSupported = false;
				}

				Client->PushSubjectStaticData_AnyThread({ SourceGuid, SubjectName }, ULiveLinkCameraRole::StaticClass(), MoveTemp(StaticDataStruct));
				EncounteredSubjects.Add(SubjectName);
			}

			// Light Subject
			if (bCreateSubject && MyTypeName == "LightSubject")
			{
				UE_LOG(ModuleLog, Warning, TEXT("HandleReceivedData - LightSubject"));
				FLiveLinkStaticDataStruct StaticDataStruct = FLiveLinkStaticDataStruct(FLiveLinkLightStaticData::StaticStruct());
				FLiveLinkLightStaticData& LightData = *StaticDataStruct.Cast<FLiveLinkLightStaticData>();

				const TSharedPtr<FJsonValue>& Lit = BoneArray[1];
				const TSharedPtr<FJsonObject> LitObject = Lit->AsObject();

				bool Intensity, LightColor, InnerConeAngle, OuterConeAngle;

				if (LitObject->TryGetBoolField(TEXT("Intensity"), Intensity))
				{
					LightData.bIsIntensitySupported = Intensity;
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid data, Intensity value not found."));
					LightData.bIsIntensitySupported = false;
				}

				if (LitObject->TryGetBoolField(TEXT("LightColor"), LightColor))
				{
					LightData.bIsLightColorSupported = LightColor;
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid data, LightColor value not found."));
					LightData.bIsLightColorSupported = false;
				}

				if (LitObject->TryGetBoolField(TEXT("InnerConeAngle"), InnerConeAngle))
				{
					LightData.bIsInnerConeAngleSupported = InnerConeAngle;
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid data, InnerConeAngle value not found."));
					LightData.bIsInnerConeAngleSupported = false;
				}

				if (LitObject->TryGetBoolField(TEXT("InnerConeAngle"), OuterConeAngle))
				{
					LightData.bIsOuterConeAngleSupported = OuterConeAngle;
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid data, OuterConeAngle value not found"));
					LightData.bIsOuterConeAngleSupported = false;
				}

				Client->PushSubjectStaticData_AnyThread({ SourceGuid, SubjectName }, ULiveLinkLightRole::StaticClass(), MoveTemp(StaticDataStruct));
				EncounteredSubjects.Add(SubjectName);
			}

			// Transform Subject
			if (bCreateSubject && MyTypeName == "TransformSubject")
			{
				UE_LOG(ModuleLog, Warning, TEXT("HandleReceivedData - TransformSubject"));
				FLiveLinkStaticDataStruct StaticDataStruct = FLiveLinkStaticDataStruct(FLiveLinkTransformStaticData::StaticStruct());
				Client->PushSubjectStaticData_AnyThread({ SourceGuid, SubjectName }, ULiveLinkTransformRole::StaticClass(), MoveTemp(StaticDataStruct));
				EncounteredSubjects.Add(SubjectName);
			}

			// Character Subject
			if (bCreateSubject && MyTypeName == "CharacterSubject")
			{
				UE_LOG(ModuleLog, Warning, TEXT("HandleReceivedData - CharacterSubject"));
				FLiveLinkStaticDataStruct StaticDataStruct = FLiveLinkStaticDataStruct(FLiveLinkSkeletonStaticData::StaticStruct());
				FLiveLinkSkeletonStaticData& StaticData = *StaticDataStruct.Cast<FLiveLinkSkeletonStaticData>();

				StaticData.BoneNames.SetNumUninitialized(BoneArray.Num() - 1);
				StaticData.BoneParents.SetNumUninitialized(BoneArray.Num() - 1);

				for (int BoneIdx = 0; BoneIdx < BoneArray.Num() - 1; ++BoneIdx)
				{
					const TSharedPtr<FJsonValue>& Bone = BoneArray[BoneIdx + 1];
					const TSharedPtr<FJsonObject> BoneObject = Bone->AsObject();

					FString BoneName;
					if (BoneObject->TryGetStringField(TEXT("Name"), BoneName))
					{
						StaticData.BoneNames[BoneIdx] = FName(*BoneName);
					}
					else
					{
						UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid bone name"));
						return;
					}

					int32 BoneParentIdx;
					if (BoneObject->TryGetNumberField(TEXT("Parent"), BoneParentIdx))
					{
						StaticData.BoneParents[BoneIdx] = BoneParentIdx;
					}
					else
					{
						UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid bone parent index"));
						return;
					}
				}

				Client->PushSubjectStaticData_AnyThread({ SourceGuid, SubjectName }, ULiveLinkAnimationRole::StaticClass(), MoveTemp(StaticDataStruct));
				EncounteredSubjects.Add(SubjectName);
			}

			// Transform Animation
			if (MyTypeName == "TransformAnimation")
			{
				FLiveLinkFrameDataStruct FrameDataStruct = FLiveLinkFrameDataStruct(FLiveLinkTransformFrameData::StaticStruct());
				FLiveLinkTransformFrameData& FrameData = *FrameDataStruct.Cast<FLiveLinkTransformFrameData>();

				const TSharedPtr<FJsonValue>& Transform = BoneArray[1];
				const TSharedPtr<FJsonObject> TransformObject = Transform->AsObject();

				const TArray<TSharedPtr<FJsonValue>>* LocationArray;
				FVector TransformLocation;
				if (TransformObject->TryGetArrayField(TEXT("Location"), LocationArray)
					&& LocationArray->Num() == 3)
				{
					double X = (*LocationArray)[0]->AsNumber();
					double Y = (*LocationArray)[1]->AsNumber();
					double Z = (*LocationArray)[2]->AsNumber();
					TransformLocation = FVector(X, Y, Z);
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid transform location"));
					return;
				}

				const TArray<TSharedPtr<FJsonValue>>* RotationArray;
				FQuat TransformQuat;
				if (TransformObject->TryGetArrayField(TEXT("Rotation"), RotationArray)
					&& RotationArray->Num() == 4)
				{
					double X = (*RotationArray)[0]->AsNumber();
					double Y = (*RotationArray)[1]->AsNumber();
					double Z = (*RotationArray)[2]->AsNumber();
					double W = (*RotationArray)[3]->AsNumber();
					TransformQuat = FQuat(X, Y, Z, W);
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid transform rotation"));
					return;
				}

				const TArray<TSharedPtr<FJsonValue>>* ScaleArray;
				FVector TransformScale;
				if (TransformObject->TryGetArrayField(TEXT("Scale"), ScaleArray)
					&& ScaleArray->Num() == 3)
				{
					double X = (*ScaleArray)[0]->AsNumber();
					double Y = (*ScaleArray)[1]->AsNumber();
					double Z = (*ScaleArray)[2]->AsNumber();
					TransformScale = FVector(X, Y, Z);
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid transform scale"));
					return;
				}

				FrameData.Transform = FTransform(TransformQuat, TransformLocation, TransformScale);

				Client->PushSubjectFrameData_AnyThread({ SourceGuid, SubjectName }, MoveTemp(FrameDataStruct));
			}

			// Camera Animation
			if (MyTypeName == "CameraAnimation")
			{
				FLiveLinkFrameDataStruct FrameDataStruct = FLiveLinkFrameDataStruct(FLiveLinkCameraFrameData::StaticStruct());
				FLiveLinkCameraFrameData& FrameData = *FrameDataStruct.Cast<FLiveLinkCameraFrameData>();

				const TSharedPtr<FJsonValue>& Camera = BoneArray[1];
				const TSharedPtr<FJsonObject> CameraObject = Camera->AsObject();

				const TArray<TSharedPtr<FJsonValue>>* LocationArray;
				FVector CameraLocation;
				if (CameraObject->TryGetArrayField(TEXT("Location"), LocationArray)
					&& LocationArray->Num() == 3)
				{
					double X = (*LocationArray)[0]->AsNumber();
					double Y = (*LocationArray)[1]->AsNumber();
					double Z = (*LocationArray)[2]->AsNumber();
					CameraLocation = FVector(X, Y, Z);
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid camera location"));
					return;
				}

				const TArray<TSharedPtr<FJsonValue>>* RotationArray;
				FQuat CameraQuat;
				if (CameraObject->TryGetArrayField(TEXT("Rotation"), RotationArray)
					&& RotationArray->Num() == 4)
				{
					double X = (*RotationArray)[0]->AsNumber();
					double Y = (*RotationArray)[1]->AsNumber();
					double Z = (*RotationArray)[2]->AsNumber();
					double W = (*RotationArray)[3]->AsNumber();
					CameraQuat = FQuat(X, Y, Z, W);
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid camera rotation"));
					return;
				}

				const TArray<TSharedPtr<FJsonValue>>* ScaleArray;
				FVector CameraScale;
				if (CameraObject->TryGetArrayField(TEXT("Scale"), ScaleArray)
					&& ScaleArray->Num() == 3)
				{
					double X = (*ScaleArray)[0]->AsNumber();
					double Y = (*ScaleArray)[1]->AsNumber();
					double Z = (*ScaleArray)[2]->AsNumber();
					CameraScale = FVector(X, Y, Z);
				}
				else
				{
					// If camera scale is not provided, default to (1,1,1)
					CameraScale = FVector(1, 1, 1);
				}

				FrameData.Transform = FTransform(CameraQuat, CameraLocation, CameraScale);

				const TArray<TSharedPtr<FJsonValue>>* CamValuesArray;
				if (CameraObject->TryGetArrayField(TEXT("Values"), CamValuesArray)
					&& CamValuesArray->Num() == 3)
				{
					double horizontalFieldOfView = (*CamValuesArray)[0]->AsNumber();
					double aspectRatio = (*CamValuesArray)[1]->AsNumber();
					double focalLength = (*CamValuesArray)[2]->AsNumber();

					FrameData.FieldOfView = horizontalFieldOfView;
					FrameData.AspectRatio = aspectRatio;
					FrameData.FocalLength = focalLength;
				}

				Client->PushSubjectFrameData_AnyThread({ SourceGuid, SubjectName }, MoveTemp(FrameDataStruct));
			}

			// Light Animation
			if (MyTypeName == "LightAnimation")
			{
				FLiveLinkFrameDataStruct FrameDataStruct = FLiveLinkFrameDataStruct(FLiveLinkLightFrameData::StaticStruct());
				FLiveLinkLightFrameData& FrameData = *FrameDataStruct.Cast<FLiveLinkLightFrameData>();

				const TSharedPtr<FJsonValue>& Light = BoneArray[1];
				const TSharedPtr<FJsonObject> LightObject = Light->AsObject();

				const TArray<TSharedPtr<FJsonValue>>* LocationArray;
				FVector LightLocation;
				if (LightObject->TryGetArrayField(TEXT("Location"), LocationArray)
					&& LocationArray->Num() == 3)
				{
					double X = (*LocationArray)[0]->AsNumber();
					double Y = (*LocationArray)[1]->AsNumber();
					double Z = (*LocationArray)[2]->AsNumber();
					LightLocation = FVector(X, Y, Z);
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid light location"));
					return;
				}

				const TArray<TSharedPtr<FJsonValue>>* RotationArray;
				FQuat LightQuat;
				if (LightObject->TryGetArrayField(TEXT("Rotation"), RotationArray)
					&& RotationArray->Num() == 4)
				{
					double X = (*RotationArray)[0]->AsNumber();
					double Y = (*RotationArray)[1]->AsNumber();
					double Z = (*RotationArray)[2]->AsNumber();
					double W = (*RotationArray)[3]->AsNumber();
					LightQuat = FQuat(X, Y, Z, W);
				}
				else
				{
					UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - invalid light rotation"));
					return;
				}

				const TArray<TSharedPtr<FJsonValue>>* ScaleArray;
				FVector LightScale;
				if (LightObject->TryGetArrayField(TEXT("Scale"), ScaleArray)
					&& ScaleArray->Num() == 3)
				{
					double X = (*ScaleArray)[0]->AsNumber();
					double Y = (*ScaleArray)[1]->AsNumber();
					double Z = (*ScaleArray)[2]->AsNumber();
					LightScale = FVector(X, Y, Z);
				}
				else
				{
					LightScale = FVector(1, 1, 1);
				}

				FrameData.Transform = FTransform(LightQuat, LightLocation, LightScale);

				const TArray<TSharedPtr<FJsonValue>>* IntensityArray;
				if (LightObject->TryGetArrayField(TEXT("Intensity"), IntensityArray)
					&& IntensityArray->Num() == 1)
				{
					double Intensity = (*IntensityArray)[0]->AsNumber();
					FrameData.Intensity = Intensity;
				}

				const TArray<TSharedPtr<FJsonValue>>* ColorArray;
				if (LightObject->TryGetArrayField(TEXT("LightColor"), ColorArray)
					&& ColorArray->Num() == 3)
				{
					uint8 R = (*ColorArray)[0]->AsNumber();
					uint8 G = (*ColorArray)[1]->AsNumber();
					uint8 B = (*ColorArray)[2]->AsNumber();
					FrameData.LightColor = FColor(R, G, B, 255);
				}

				const TArray<TSharedPtr<FJsonValue>>* ConeArray;
				if (LightObject->TryGetArrayField(TEXT("Angle"), ConeArray)
					&& ConeArray->Num() == 2)
				{
					double InnerConeAngle = (*ConeArray)[0]->AsNumber();
					double OuterConeAngle = (*ConeArray)[1]->AsNumber();
					FrameData.InnerConeAngle = InnerConeAngle;
					FrameData.OuterConeAngle = OuterConeAngle;
				}

				Client->PushSubjectFrameData_AnyThread({ SourceGuid, SubjectName }, MoveTemp(FrameDataStruct));
			}

			// Character Animation
			if (MyTypeName == "CharacterAnimation")
			{
				FLiveLinkFrameDataStruct FrameDataStruct = FLiveLinkFrameDataStruct(FLiveLinkAnimationFrameData::StaticStruct());
				FLiveLinkAnimationFrameData& FrameData = *FrameDataStruct.Cast<FLiveLinkAnimationFrameData>();

				FrameData.Transforms.SetNumUninitialized(BoneArray.Num() - 1);

				for (int BoneIdx = 0; BoneIdx < BoneArray.Num() - 1; ++BoneIdx)
				{
					const TSharedPtr<FJsonValue>& Bone = BoneArray[BoneIdx + 1];
					const TSharedPtr<FJsonObject> BoneObject = Bone->AsObject();

					const TArray<TSharedPtr<FJsonValue>>* LocationArray;
					FVector BoneLocation;
					if (BoneObject->TryGetArrayField(TEXT("Location"), LocationArray)
						&& LocationArray->Num() == 3)
					{
						double X = (*LocationArray)[0]->AsNumber();
						double Y = (*LocationArray)[1]->AsNumber();
						double Z = (*LocationArray)[2]->AsNumber();
						BoneLocation = FVector(X, Y, Z);
					}
					else
					{
						UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - index[%i] invalid location"), BoneIdx);
						return;
					}

					const TArray<TSharedPtr<FJsonValue>>* RotationArray;
					FQuat BoneQuat;
					if (BoneObject->TryGetArrayField(TEXT("Rotation"), RotationArray)
						&& RotationArray->Num() == 4)
					{
						double X = (*RotationArray)[0]->AsNumber();
						double Y = (*RotationArray)[1]->AsNumber();
						double Z = (*RotationArray)[2]->AsNumber();
						double W = (*RotationArray)[3]->AsNumber();
						BoneQuat = FQuat(X, Y, Z, W);
					}
					else
					{
						UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - index[%i] invalid rotation"), BoneIdx);
						return;
					}

					const TArray<TSharedPtr<FJsonValue>>* ScaleArray;
					FVector BoneScale;
					if (BoneObject->TryGetArrayField(TEXT("Scale"), ScaleArray)
						&& ScaleArray->Num() == 3)
					{
						double X = (*ScaleArray)[0]->AsNumber();
						double Y = (*ScaleArray)[1]->AsNumber();
						double Z = (*ScaleArray)[2]->AsNumber();
						BoneScale = FVector(X, Y, Z);
					}
					else
					{
						UE_LOG(ModuleLog, Error, TEXT("HandleReceivedData - index[%i] invalid scale"), BoneIdx);
						return;
					}

					FrameData.Transforms[BoneIdx] = FTransform(BoneQuat, BoneLocation, BoneScale);
				}

				Client->PushSubjectFrameData_AnyThread({ SourceGuid, SubjectName }, MoveTemp(FrameDataStruct));
			}
		}
	}
}

#undef LOCTEXT_NAMESPACE
