#pragma once

#include "Widgets/SCompoundWidget.h"
#include "Input/Reply.h"
#include "Types/SlateEnums.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Interfaces/IPv4/IPv4Endpoint.h"  // Needed for FIPv4Endpoint

// We do not need to reference FOnLiveLinkSourceCreated here.
// That type is used only in the factory class.

class SEditableTextBox;

class SJSONLiveLinkSourceFactory : public SCompoundWidget
{
public:
    // Declare a one-parameter delegate that only takes an FIPv4Endpoint.
    DECLARE_DELEGATE_OneParam(FOnOkClicked, FIPv4Endpoint);

    SLATE_BEGIN_ARGS(SJSONLiveLinkSourceFactory) {}
        SLATE_EVENT(FOnOkClicked, OnOkClicked)
    SLATE_END_ARGS()

    void Construct(const FArguments& Args);

private:
    void OnEndpointChanged(const FText& NewValue, ETextCommit::Type CommitType);
    FReply OnOkClicked();

    TWeakPtr<SEditableTextBox> EditabledText;
    FOnOkClicked OkClicked;
};
